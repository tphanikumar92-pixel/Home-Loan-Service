package com.example.homeloanddsa

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.util.Locale
import java.util.UUID

private val inr = NumberFormat.getCurrencyInstance(Locale("en", "IN"))
private fun money(v: Double) = inr.format(v).replace("₹", "₹ ")

 data class Lead(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val phone: String,
    val area: String,
    val product: String,
    val amount: Double,
    val status: String,
    val followUp: String,
    val notes: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = lightColorScheme(primary = androidx.compose.ui.graphics.Color(0xFF145A45))) { HomeLoanApp(this) } }
    }
}

@Composable
fun HomeLoanApp(context: Context) {
    val prefs = remember { context.getSharedPreferences("home_loan_dsa", Context.MODE_PRIVATE) }
    fun readLeads(): List<Lead> {
        val arr = runCatching { JSONArray(prefs.getString("leads", "[]")) }.getOrElse { JSONArray() }
        return (0 until arr.length()).mapNotNull { i -> runCatching {
            val o = arr.getJSONObject(i)
            Lead(o.optString("id"), o.optString("name"), o.optString("phone"), o.optString("area"), o.optString("product"), o.optDouble("amount"), o.optString("status"), o.optString("followUp"), o.optString("notes"))
        }.getOrNull() }
    }
    var leads by remember { mutableStateOf(readLeads()) }
    var tab by remember { mutableStateOf(0) }
    var showAdd by remember { mutableStateOf(false) }
    fun save(list: List<Lead>) {
        val arr = JSONArray()
        list.forEach { l -> arr.put(JSONObject().put("id", l.id).put("name", l.name).put("phone", l.phone).put("area", l.area).put("product", l.product).put("amount", l.amount).put("status", l.status).put("followUp", l.followUp).put("notes", l.notes)) }
        prefs.edit().putString("leads", arr.toString()).apply(); leads = list
    }
    Scaffold(
        topBar = { TopAppBarCompat(title = "Home Loan DSA", subtitle = "Lead & Business Manager") },
        bottomBar = { NavigationBar { listOf("Dashboard", "Leads", "Follow-ups", "EMI", "Reports").forEachIndexed { i, label ->
            val icons = listOf(Icons.Default.Home, Icons.Default.People, Icons.Default.Event, Icons.Default.Calculate, Icons.Default.BarChart)
            NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Icon(icons[i], contentDescription = label) }, label = { Text(label, maxLines = 1) })
        } } },
        floatingActionButton = { if (tab == 1 || tab == 0) FloatingActionButton(onClick = { showAdd = true }) { Icon(Icons.Default.Add, contentDescription = "Add lead") } }
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            when (tab) {
                0 -> Dashboard(leads, onAdd = { showAdd = true }, onLeads = { tab = 1 })
                1 -> LeadList(leads, onStatus = { lead, status -> save(leads.map { if (it.id == lead.id) it.copy(status = status) else it }) }, onDelete = { lead -> save(leads.filterNot { it.id == lead.id }) })
                2 -> FollowUps(leads, onStatus = { lead, status -> save(leads.map { if (it.id == lead.id) it.copy(status = status) else it }) })
                3 -> EmiScreen()
                else -> Reports(leads)
            }
        }
    }
    if (showAdd) AddLeadDialog(onDismiss = { showAdd = false }, onSave = { lead -> save(listOf(lead) + leads); showAdd = false; tab = 1 })
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TopAppBarCompat(title: String, subtitle: String) {
    Column(Modifier.fillMaxWidth()) {
        TopAppBar(title = { Column { Text(title, fontWeight = FontWeight.Bold); Text(subtitle, style = MaterialTheme.typography.labelSmall) } })
    }
}

@Composable
fun Dashboard(leads: List<Lead>, onAdd: () -> Unit, onLeads: () -> Unit) {
    val active = leads.count { it.status !in listOf("Disbursed", "Not Interested") }
    val follow = leads.count { it.followUp.isNotBlank() && it.status != "Disbursed" }
    val login = leads.count { it.status in listOf("Login Completed", "Sanctioned", "Disbursed") }
    val disb = leads.filter { it.status == "Disbursed" }.sumOf { it.amount }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary)) {
            Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Grow your DSA business", color = MaterialTheme.colorScheme.onPrimary, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text("Capture leads. Follow up on time. Track conversions.", color = MaterialTheme.colorScheme.onPrimary)
                Button(onClick = onAdd, colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surface, contentColor = MaterialTheme.colorScheme.primary)) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(6.dp)); Text("Add customer lead") }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricCard("Total leads", leads.size.toString(), Modifier.weight(1f))
            MetricCard("Active leads", active.toString(), Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricCard("Login stage", login.toString(), Modifier.weight(1f))
            MetricCard("Follow-ups", follow.toString(), Modifier.weight(1f))
        }
        Card { Column(Modifier.fillMaxWidth().padding(16.dp)) { Text("Disbursed lead value", style = MaterialTheme.typography.titleMedium); Text(money(disb), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold); Text("Based on leads marked Disbursed", style = MaterialTheme.typography.bodySmall) } }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) { Text("Recent leads", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold); TextButton(onClick = onLeads) { Text("View all") } }
        if (leads.isEmpty()) EmptyState("No leads added yet", "Tap Add customer lead to get started.") else leads.take(3).forEach { LeadCard(it, onStatus = {}, onDelete = null) }
    }
}

@Composable
fun MetricCard(title: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier) { Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) { Text(title, style = MaterialTheme.typography.bodyMedium); Text(value, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary) } }
}

@Composable
fun LeadList(leads: List<Lead>, onStatus: (Lead, String) -> Unit, onDelete: (Lead) -> Unit) {
    var query by remember { mutableStateOf("") }
    val filtered = leads.filter { (it.name + it.phone + it.area + it.status).contains(query, ignoreCase = true) }
    Column(Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
        OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth().padding(vertical = 8.dp), label = { Text("Search name, mobile, area") }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true)
        if (filtered.isEmpty()) EmptyState("No leads found", "Add a new customer using the + button.") else LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 18.dp)) {
            items(filtered, key = { it.id }) { lead -> LeadCard(lead, onStatus, onDelete) }
        }
    }
}

@Composable
fun LeadCard(lead: Lead, onStatus: (Lead, String) -> Unit, onDelete: ((Lead) -> Unit)?) {
    var expanded by remember { mutableStateOf(false) }
    Card { Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { Text(lead.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold); Text("${lead.phone} • ${lead.area}", style = MaterialTheme.typography.bodySmall) }
            AssistChip(onClick = { expanded = true }, label = { Text(lead.status) }, trailingIcon = { Icon(Icons.Default.ArrowDropDown, null) })
            DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                listOf("New Lead", "Contacted", "Interested", "Follow-up", "Login Completed", "Sanctioned", "Disbursed", "Not Interested").forEach { s -> DropdownMenuItem(text = { Text(s) }, onClick = { onStatus(lead, s); expanded = false }) }
            }
        }
        Text("${lead.product} • ${money(lead.amount)}", fontWeight = FontWeight.Medium)
        if (lead.followUp.isNotBlank()) Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Event, null, Modifier.size(16.dp)); Spacer(Modifier.width(5.dp)); Text("Follow-up: ${lead.followUp}", style = MaterialTheme.typography.bodySmall) }
        if (lead.notes.isNotBlank()) Text(lead.notes, style = MaterialTheme.typography.bodySmall)
        if (onDelete != null) Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) { TextButton(onClick = { onDelete(lead) }) { Icon(Icons.Default.DeleteOutline, null); Text("Delete") } }
    } }
}

@Composable
fun FollowUps(leads: List<Lead>, onStatus: (Lead, String) -> Unit) {
    val items = leads.filter { it.followUp.isNotBlank() && it.status != "Disbursed" && it.status != "Not Interested" }.sortedBy { it.followUp }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Follow-up planner", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("Review these customers and update their status.", style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(12.dp))
        if (items.isEmpty()) EmptyState("No follow-ups scheduled", "Add a follow-up date when registering a lead.") else LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) { items(items, key = { it.id }) { LeadCard(it, onStatus, null) } }
    }
}

@Composable
fun EmiScreen() {
    var principalText by remember { mutableStateOf("2500000") }
    var rateText by remember { mutableStateOf("9.5") }
    var yearsText by remember { mutableStateOf("20") }
    val principal = principalText.toDoubleOrNull()?.coerceAtLeast(0.0) ?: 0.0
    val rate = rateText.toDoubleOrNull()?.coerceAtLeast(0.0) ?: 0.0
    val years = yearsText.toIntOrNull()?.coerceAtLeast(0) ?: 0
    val n = years * 12
    val r = rate / 1200.0
    val emi = if (n == 0) 0.0 else if (r == 0.0) principal / n else principal * r * Math.pow(1 + r, n) / (Math.pow(1 + r, n) - 1)
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Home loan EMI calculator", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        OutlinedTextField(principalText, { principalText = it.filter { c -> c.isDigit() } }, Modifier.fillMaxWidth(), label = { Text("Loan amount (₹)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
        OutlinedTextField(rateText, { rateText = it.filter { c -> c.isDigit() || c == '.' } }, Modifier.fillMaxWidth(), label = { Text("Annual interest rate (%)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
        OutlinedTextField(yearsText, { yearsText = it.filter(Char::isDigit) }, Modifier.fillMaxWidth(), label = { Text("Tenure (years)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) { Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Estimated monthly EMI", style = MaterialTheme.typography.titleMedium)
            Text(money(emi), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text("Total interest: ${money((emi * n - principal).coerceAtLeast(0.0))}")
            Text("Total repayment: ${money(emi * n)}")
        } }
        Text("Illustrative only. The lender's actual rate, fees and terms may differ.", style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun Reports(leads: List<Lead>) {
    val stages = listOf("New Lead", "Contacted", "Interested", "Follow-up", "Login Completed", "Sanctioned", "Disbursed", "Not Interested")
    val totalValue = leads.sumOf { it.amount }
    val disbursedValue = leads.filter { it.status == "Disbursed" }.sumOf { it.amount }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Business reports", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        MetricCard("Total leads", leads.size.toString(), Modifier.fillMaxWidth())
        MetricCard("Pipeline loan value", money(totalValue), Modifier.fillMaxWidth())
        MetricCard("Disbursed lead value", money(disbursedValue), Modifier.fillMaxWidth())
        Text("Lead stage breakdown", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        stages.forEach { stage ->
            val count = leads.count { it.status == stage }
            Card { Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Text(stage, Modifier.weight(1f)); Text(count.toString(), fontWeight = FontWeight.Bold) } }
        }
        Text("Reports are based on leads entered on this device. This version does not sync to a cloud or bank CRM.", style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun AddLeadDialog(onDismiss: () -> Unit, onSave: (Lead) -> Unit) {
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var area by remember { mutableStateOf("Ongole") }
    var product by remember { mutableStateOf("Home Loan") }
    var amount by remember { mutableStateOf("2500000") }
    var followUp by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }
    val areas = listOf("Ongole", "Addanki", "Chirala", "Tenali", "Other")
    val products = listOf("Home Loan", "Loan Against Property", "Balance Transfer", "Home Construction")
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Add customer lead") }, text = {
        Column(Modifier.heightIn(max = 560.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            OutlinedTextField(name, { name = it; error = "" }, Modifier.fillMaxWidth(), label = { Text("Customer name *") }, singleLine = true)
            OutlinedTextField(phone, { phone = it.filter(Char::isDigit).take(10); error = "" }, Modifier.fillMaxWidth(), label = { Text("Mobile number *") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), singleLine = true)
            Text("Area / branch", style = MaterialTheme.typography.labelLarge)
            DropdownField(area, areas, { area = it })
            Text("Loan product", style = MaterialTheme.typography.labelLarge)
            DropdownField(product, products, { product = it })
            OutlinedTextField(amount, { amount = it.filter(Char::isDigit) }, Modifier.fillMaxWidth(), label = { Text("Required loan amount (₹) *") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
            OutlinedTextField(followUp, { followUp = it }, Modifier.fillMaxWidth(), label = { Text("Follow-up date (DD/MM/YYYY)") }, placeholder = { Text("e.g. 15/10/2026") }, singleLine = true)
            OutlinedTextField(notes, { notes = it }, Modifier.fillMaxWidth(), label = { Text("Notes / next action") }, minLines = 2)
            if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        }
    }, confirmButton = { Button(onClick = {
        when {
            name.isBlank() -> error = "Enter customer name."
            !Regex("^[6-9][0-9]{9}$").matches(phone) -> error = "Enter a valid 10-digit Indian mobile number."
            (amount.toDoubleOrNull() ?: 0.0) <= 0 -> error = "Enter a valid loan amount."
            else -> onSave(Lead(name = name.trim(), phone = phone, area = area, product = product, amount = amount.toDouble(), status = "New Lead", followUp = followUp.trim(), notes = notes.trim()))
        }
    }) { Text("Save lead") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } })
}

@Composable
fun DropdownField(value: String, options: List<String>, onSelect: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Box {
        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Text(value, Modifier.weight(1f)); Icon(Icons.Default.ArrowDropDown, null) }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) { options.forEach { option -> DropdownMenuItem(text = { Text(option) }, onClick = { onSelect(option); expanded = false }) } }
    }
}

@Composable
fun EmptyState(title: String, detail: String) {
    Column(Modifier.fillMaxWidth().padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Icon(Icons.Default.Inbox, null, Modifier.size(44.dp), tint = MaterialTheme.colorScheme.primary)
        Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Text(detail, style = MaterialTheme.typography.bodyMedium)
    }
}
