# Home Loan DSA — Android starter project

A native Android app starter for an independent Home Loan DSA marketing business, built with Kotlin and Jetpack Compose.

## Included
- Dashboard: lead count, active pipeline, login-stage count, follow-ups, disbursed lead value
- Lead register: add, search, update status, delete
- Follow-up planner: displays leads with a follow-up date
- EMI calculator: loan amount, annual interest rate, tenure, monthly EMI, total interest and repayment
- Reports: lead-stage breakdown and pipeline/disbursed values
- Local on-device persistence with SharedPreferences JSON

## Open and build
1. Install Android Studio (current stable) and a JDK supported by Android Studio.
2. Open this folder (`HomeLoanDSAAndroid`) in Android Studio.
3. Allow Gradle sync to finish; install Android SDK 35 if prompted.
4. Run on an Android device or emulator (minimum Android 8.0 / API 26).
5. To create an APK, use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

## Important limitations
- This is a starter source project, not a prebuilt APK. It has not been compiled or tested on a physical device in this environment.
- Data stays on this phone only. There is no cloud backup, multi-user login, automatic reminders, WhatsApp integration, lead export, or bank/CRM integration yet.
- Do not store Aadhaar, PAN, bank statements, or other sensitive documents in this prototype. Add secure authentication, encrypted storage, privacy notices and consent workflows before production use.
- Loan amounts are customer-provided pipeline values. Marking a lead as disbursed is a manual status update, not confirmation of lender disbursement.
